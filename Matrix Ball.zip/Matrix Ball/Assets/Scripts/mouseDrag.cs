﻿using UnityEngine;
using System.Collections;

public class mouseDrag : MonoBehaviour {
    public float distance = 9.5f;
    public float speed = 10f;
    private Rigidbody rb;
    public GameObject particle;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void OnMouseDrag()
    {
        Vector3 mousePoint = new Vector3(Input.mousePosition.x, Input.mousePosition.y, distance);
        Vector3 objPosition = Camera.main.ScreenToWorldPoint(mousePoint);

        transform.position = objPosition;
    }

    void OnMouseUp()
    {
        Vector3 mousePoint = new Vector3(Input.mousePosition.x, Input.mousePosition.y, distance);
        Vector3 objPosition = Camera.main.ScreenToWorldPoint(mousePoint);
        Vector3 difference = objPosition - transform.position;
        rb.AddForce(difference * speed, ForceMode.Impulse);
        //Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        //if (Physics.Raycast(ray))
        //{
        //    Instantiate(particle, objPosition, Quaternion.identity);
        //}
        //Debug.Log("transform --" + transform.position);
        //Debug.Log("mouse --" + Input.mousePosition);
        //Debug.Log("obj --" + objPosition);
        
        //Debug.Log("difference --" + difference);

    }

    void FixedUpdate()
    {
        
    }

}
