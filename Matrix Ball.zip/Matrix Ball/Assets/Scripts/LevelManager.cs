﻿using UnityEngine;
using System.Collections;

public class LevelManager : MonoBehaviour {
    private GameObject player;
    private float PlayerZ;
    private float PlayerX;
    public GameObject currentCheckpoint;

    // Use this for initialization
    void Start () {
        player = GameObject.FindWithTag("Player");
	}
	
	// Update is called once per frame
	void Update () {
        PlayerZ = player.transform.position.z;
        PlayerX = player.transform.position.x;
        if (PlayerZ > 5)
        {
            RespawnPlayer();
        }
        if (PlayerX > 5 || PlayerX < -5)
        {
            RespawnPlayer();
        }
    }

    public void RespawnPlayer()
    {
        Debug.Log("Player Respawn");
        player.transform.position = currentCheckpoint.transform.position;
    }
}
